import React from "react";
import Navbar from "./components /Navbar";

function App() {

  return (
    <>
      <h1 className="bg-black">
        Hello
      </h1>
      <Navbar/>
    </>
  )
}

export default App
