import React from "react";



function Navbar(){
  return(
    
    <>
      <div className="flex flex-row items-center justify-center w-full gap-12 bg-white">
        <p>
          Home
        </p>
        <p>
          Events 
          </p>
          <p>
          About Us
          </p>
          <p>
            Articles
          </p>
          <p> 
              Quiz
          </p>

      </div>
    
    </>
  )
}

export default Navbar;